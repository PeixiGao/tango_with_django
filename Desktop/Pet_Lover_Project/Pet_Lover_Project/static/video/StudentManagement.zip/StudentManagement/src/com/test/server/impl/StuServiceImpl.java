package com.test.server.impl;

import java.util.List;

import com.test.DAO.StuDao;
import com.test.entity.ChooseProject;
import com.test.entity.Grade;
import com.test.entity.StuBridthDay;
import com.test.entity.StuClassmate;
import com.test.entity.StuDate;
import com.test.server.StuServer;

public class StuServiceImpl implements StuServer{
	
	private StuDao stuDao;

	public void setStuDao(StuDao stuDao) {
		this.stuDao = stuDao;
	}

	//����ȫ��ѧ����Ϣ
	@Override
	public List getStuList() {
		return stuDao.getStuList();
	}
	//ɾ��ѧ��
	@Override
	public boolean deltestu(int cno) {
		return stuDao.deltestu(cno);
	}

	//����ѧ��
	@Override
	public boolean addStuDate(StuDate studate, StuBridthDay stubridthday,
			Grade grade, StuClassmate stuclassmate, ChooseProject chooseproject) {
		return stuDao.addStuDate(studate,stubridthday,grade,stuclassmate,chooseproject);
	}

	//�޸���Ϣ
	@Override
	public List updatestu(int cno) {
		//�޸�ǰ������Ҫ�޸ĵ���Ϣ
		return stuDao.updatestu(cno);
	}
	//ִ���޸Ĳ���
	@Override
	public boolean doupdatestu(StuDate studate, StuBridthDay stubridthday,
			Grade grade, StuClassmate stuclassmate, ChooseProject chooseproject) {
		return stuDao.updatestu(studate,stubridthday,grade,stuclassmate,chooseproject);//ִ���޸�
	}

	
	
}
