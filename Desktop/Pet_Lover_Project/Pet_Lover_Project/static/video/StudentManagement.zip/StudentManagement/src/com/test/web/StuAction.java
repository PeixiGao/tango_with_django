package com.test.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.test.entity.ChooseProject;
import com.test.entity.Grade;
import com.test.entity.StuBridthDay;
import com.test.entity.StuClassmate;
import com.test.entity.StuDate;
import com.test.server.StuServer;

public class StuAction{
	private StuServer stuserves;
	//����һ������
	private List list;
	//����һ�����Ͳ���
	private int cno;
	//˽�л�����
	private StuDate studate;
	private StuClassmate stuclassmate;
	private StuBridthDay stubridthday;
	private Grade grade;
	private ChooseProject chooseproject;

	//��ʾȫ���б���Ϣ
	public String getStuList(){
		list=stuserves.getStuList();
		return "findlist";
	}
	//�޸���Ϣ
	public String updatestu(){
		//�޸�ǰ������Ҫ�޸ĵ���Ϣ
		list=stuserves.updatestu(cno);
		return "toupdatestu";
	}	
		//ִ���޸Ĳ���
	public String doupdatestu() throws IOException{//�޸�
		HttpServletResponse response=ServletActionContext.getResponse();//���
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		if(stuserves.doupdatestu(studate,stubridthday,grade,stuclassmate,chooseproject))
			out.print("<script>alert('�޸ĳɹ�');location.href='stuAction_getStuList';</script>");
		else
			out.print("<script>alert('�޸�ʧ��');history.back()</script>");	
		
		out.close();//�ر���
		return null;	
	}
	
	
	//ɾ��ѧ����Ϣ
	public String deltestu() throws IOException{
		//���
		HttpServletResponse response=ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		if(stuserves.deltestu(cno))
			out.print("<script>alert('ɾ���ɹ�');location.href='stuAction_getStuList';</script>");
		else
			out.print("<script>alert('����ʧ��');history.back()</script>");
		out.close();//�ر���
		return null;
	}
	
	//����ѧ����Ϣ
	public String toaddfindcls(){
		//����ǰ����ѡ�޿�Ŀ 	
		list=stuserves.getStuList();
		return "toaddfindcls";
	}
		//ִ������ѧ��
	public void addStuDate() throws IOException{		
		HttpServletResponse response=ServletActionContext.getResponse();//���
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		if(stuserves.addStuDate(studate,stubridthday,grade,stuclassmate,chooseproject))
			out.print("<script>alert('���ӳɹ�');location.href='stuAction_getStuList';</script>");
		else
			out.print("<script>alert('����ʧ��');history.back()</script>");
		out.close();//�ر���
	}
	
	
	//����get,set����
	public void setStuserves(StuServer stuserves) {
		this.stuserves = stuserves;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public StuServer getStuserves() {
		return stuserves;
	}

	public int getCno() {
		return cno;
	}

	public void setCno(int cno) {
		this.cno = cno;
	}

	public StuDate getStudate() {
		return studate;
	}

	public void setStudate(StuDate studate) {
		this.studate = studate;
	}

	public StuClassmate getStuclassmate() {
		return stuclassmate;
	}

	public void setStuclassmate(StuClassmate stuclassmate) {
		this.stuclassmate = stuclassmate;
	}

	public StuBridthDay getStubridthday() {
		return stubridthday;
	}

	public void setStubridthday(StuBridthDay stubridthday) {
		this.stubridthday = stubridthday;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public ChooseProject getChooseproject() {
		return chooseproject;
	}

	public void setChooseproject(ChooseProject chooseproject) {
		this.chooseproject = chooseproject;
	}
}
