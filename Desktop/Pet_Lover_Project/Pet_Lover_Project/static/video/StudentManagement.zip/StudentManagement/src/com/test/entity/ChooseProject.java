package com.test.entity;

import java.util.HashSet;
import java.util.Set;

public class ChooseProject {
	private int pcno;
	//ѧ������
	private String proname;
	
	
	//ѡ�޿�Ŀ��ѧ����Ϣ�Ĺ�ϵ�ǣ���Զ�
	private Set<StuDate> stuDate=new HashSet<StuDate>();


	public ChooseProject() {
		super();
	}


	public ChooseProject(int pcno, String proname) {
		super();
		this.pcno = pcno;
		this.proname = proname;
	}


	public int getPcno() {
		return pcno;
	}


	public void setPcno(int pcno) {
		this.pcno = pcno;
	}


	public String getProname() {
		return proname;
	}


	public void setProname(String proname) {
		this.proname = proname;
	}


	public Set<StuDate> getStuDate() {
		return stuDate;
	}


	public void setStuDate(Set<StuDate> stuDate) {
		this.stuDate = stuDate;
	}


	public void setStuDate1(Set<StuDate> scno) {
		this.stuDate= scno;
		
	}


	public void setStuDate(int scno) {
		// TODO �Զ����ɵķ������
		
	}
}
