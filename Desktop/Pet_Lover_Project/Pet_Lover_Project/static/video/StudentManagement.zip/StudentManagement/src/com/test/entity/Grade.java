package com.test.entity;

import java.util.HashSet;
import java.util.Set;

public class Grade {
	private int gcno;
	//˽�л��༶����
	private String gname;
	
	//�����༶֮��Ĺ�ϵ�ǣ�һ�Զ�
	private Set<StuClassmate>  stuclassmate=new HashSet<StuClassmate>();

	public Grade() {
		super();
	}

	public Grade(int gcno, String gname) {
		super();
		this.gcno = gcno;
		this.gname = gname;
	}

	public int getGcno() {
		return gcno;
	}

	public void setGcno(int gcno) {
		this.gcno = gcno;
	}
	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public Set<StuClassmate> getStuclassmate() {
		return stuclassmate;
	}

	public void setStuclassmate(Set<StuClassmate> stuclassmate) {
		this.stuclassmate = stuclassmate;
	}
}
