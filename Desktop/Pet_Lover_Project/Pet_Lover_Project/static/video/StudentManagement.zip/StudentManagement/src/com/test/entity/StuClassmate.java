package com.test.entity;

import java.util.HashSet;
import java.util.Set;

public class StuClassmate {
	private int mcno;
	private int count;
		//˽�л��༶����
	private String name;
	//�༶��ѧ���Ĺ�ϵ�ǣ�һ�Զ�
	private Set<StuDate> studate=new HashSet<StuDate>();
	//�༶����͵Ĺ�ϵ�ǣ����һ
	private Grade grade;
	
	
	public StuClassmate() {
		super();
	}


	public StuClassmate(int mcno, int count, String name) {
		super();
		this.mcno = mcno;
		this.count = count;
		this.name = name;
	}


	public int getMcno() {
		return mcno;
	}


	public void setMcno(int mcno) {
		this.mcno = mcno;
	}


	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<StuDate> getStudate() {
		return studate;
	}
	public void setStudate(Set<StuDate> studate) {
		this.studate = studate;
	}
	public Grade getGrade() {
		return grade;
	}
	public void setGrade(Grade grade) {
		this.grade = grade;
	}
}
