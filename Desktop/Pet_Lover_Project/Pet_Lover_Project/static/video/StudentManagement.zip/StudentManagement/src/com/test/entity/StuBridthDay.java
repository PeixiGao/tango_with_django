package com.test.entity;

import java.util.HashSet;
import java.util.Set;

public class StuBridthDay {
	private int bsno;
	//������ַ
	private String bridwhere;
	
	//����������ѧ����ϵ�ǣ�һ�Զ�
	private Set<StuDate> stud=new HashSet<StuDate>();

	public StuBridthDay() {
		super();
	}
	public StuBridthDay(int bsno, String bridwhere) {
		super();
		this.bsno = bsno;
		this.bridwhere = bridwhere;
	}

	public int getBsno() {
		return bsno;
	}

	public void setBsno(int bsno) {
		this.bsno = bsno;
	}

	public String getBridwhere() {
		return bridwhere;
	}

	public void setBridwhere(String bridwhere) {
		this.bridwhere = bridwhere;
	}


	public Set<StuDate> getStud() {
		return stud;
	}

	public void setStud(Set<StuDate> stud) {
		this.stud = stud;
	}
	
}
