package com.test.entity;

import java.util.HashSet;
import java.util.Set;

public class StuDate {
	private int scno;
	//������
	private String stuname;
	//Ӣ����
	private String foreigname;
	//��������
	private String bridtime;
	
	//ѧ����������ڵĹ�ϵ�ǣ����һ
	private StuBridthDay stu;
	//ѧ����ѡ�޿�Ŀ�Ĺ�ϵ�Ƕ�Զ�
	private Set<ChooseProject> choProject=new HashSet<ChooseProject>();
	//ѧ����༶֮��Ĺ�ϵ��:���һ
	private StuClassmate stuclassmate;
	
	

	public StuDate() {
		super();
	}

	public StuDate(int scno, String stuname, String foreigname,String bridtime) {
		super();
		this.scno = scno;
		this.stuname = stuname;
		this.foreigname = foreigname;
		this.bridtime= bridtime;
	}

	public int getScno() {
		return scno;
	}

	public void setScno(int scno) {
		this.scno = scno;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getForeigname() {
		return foreigname;
	}
	public String getBridtime() {
		return bridtime;
	}

	public void setBridtime(String bridtime) {
		this.bridtime = bridtime;
	}

	public void setForeigname(String foreigname) {
		this.foreigname = foreigname;
	}

	public StuBridthDay getStu() {
		return stu;
	}

	public void setStu(StuBridthDay stu) {
		this.stu = stu;
	}

	public Set<ChooseProject> getChoProject() {
		return choProject;
	}
	

	public void setChoProject(Set<ChooseProject> choProject) {
		this.choProject = choProject;
	}

	public StuClassmate getStuclassmate() {
		return stuclassmate;
	}

	public void setStuclassmate(StuClassmate stuclassmate) {
		this.stuclassmate = stuclassmate;
	}
	
}
