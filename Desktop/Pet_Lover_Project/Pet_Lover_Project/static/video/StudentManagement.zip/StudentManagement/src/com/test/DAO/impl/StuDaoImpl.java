package com.test.DAO.impl;

import java.util.List;
import com.test.DAO.StuDao;
import com.test.entity.ChooseProject;
import com.test.entity.Grade;
import com.test.entity.StuBridthDay;
import com.test.entity.StuClassmate;
import com.test.entity.StuDate;

public class StuDaoImpl extends BaseDao implements StuDao{

	//����ѧ��ȫ����Ϣ
	@Override
	public List getStuList() {
		String sq = "select s.scno,s.stuname,s.foreigname,s.bridtime,sc.proname,st.bridwhere,cm.name,cg.gname,"
				+ "cm.count,cm.mcno,st.bsno,cm.mcno,s.scno from StuDate s "
				+ "inner join s.choProject sc "
				+ "inner join s.stu st "
				+ "inner join s.stuclassmate cm "
				+ "inner join cm.grade cg";	
		List list  = getSession().createQuery(sq).list();
		return list;
	}
	//ɾ��ѧ��
	@Override
	public boolean deltestu(int cno) {
		StuDate sd=(StuDate)getSession().get(StuDate.class,cno);
		getSession().delete(sd);
		return true;
	}
	//����ѧ����Ϣ
	@SuppressWarnings("unchecked")
	@Override
	public boolean addStuDate(StuDate studate, StuBridthDay stubridthday,
			Grade grade, StuClassmate stuclassmate, ChooseProject chooseproject) {
		
		//���ӳ����ص�
		getSession().save(stubridthday);
		//�����꼶
		getSession().save(grade);
		//���Ӱ༶
		Grade p=(Grade)getSession().get(Grade.class, grade.getGcno());
		StuClassmate order=new StuClassmate(0,stuclassmate.getCount()+1,stuclassmate.getName());
		order.setGrade(p);
		getSession().save(order);
		//����ѧ����Ϣ
		  //��ȡ�����ص�
		StuBridthDay sdy=(StuBridthDay) getSession().get(StuBridthDay.class, stubridthday.getBsno());
		//��ȡ�༶
		StuClassmate scm=(StuClassmate)getSession().get(StuClassmate.class, order.getMcno());
		//��ȡѡ�޿�Ŀ
		ChooseProject cpj=(ChooseProject)getSession().get(ChooseProject.class, chooseproject.getPcno());
		//����һ��ѧ����Ϣ(���һ)
		StuDate sd=new StuDate(0,studate.getStuname(),studate.getForeigname(),studate.getBridtime());
		sd.setStu(sdy);
		sd.setStuclassmate(scm);
		//����һ��ѧѡ�޿�Ŀ(��Զ�)
		ChooseProject cp=new ChooseProject(0,chooseproject.getProname());
		sd.getChoProject().add(cp);
		getSession().save(sd);
		return true;
		
	}
	//�޸�ѧ����Ϣ
	@Override
	//�޸�ǰ������Ҫ�޸ĵ���Ϣ
	public List updatestu(int cno) {
		String sq = "select s.scno,s.stuname,s.foreigname,s.bridtime,sc.proname,st.bridwhere,cm.name,cg.gname,"
				+ "cm.count,cm.mcno,st.bsno,cm.mcno,sc.pcno,cg.gcno from StuDate s "
				+ "inner join s.choProject sc "
				+ "inner join s.stu st "
				+ "inner join s.stuclassmate cm "
				+ "inner join cm.grade cg where s.scno="+cno;
		List list  = getSession().createQuery(sq).list();
		return list;
	}
	//ִ����Ҫ�޸ĵ���Ϣ
	@Override
	public boolean updatestu(StuDate studate, StuBridthDay stubridthday,
			Grade grade, StuClassmate stuclassmate, ChooseProject chooseproject) {
		//�޸ĳ����ص�
		StuBridthDay stu=(StuBridthDay)getSession().get(StuBridthDay.class,stubridthday.getBsno());
		stu.setBridwhere(stubridthday.getBridwhere());
		//�޸��꼶
		Grade g=(Grade)getSession().get(Grade.class, grade.getGcno());
		g.setGname(grade.getGname());
		//�޸İ༶
		StuClassmate scm=(StuClassmate)getSession().get(StuClassmate.class, stuclassmate.getMcno());
		scm.setName(stuclassmate.getName());
		//�޸�ѡ�޿�Ŀ
		ChooseProject cpj=(ChooseProject)getSession().get(ChooseProject.class, chooseproject.getPcno());
		cpj.setProname(chooseproject.getProname());
		//�޸�ѧ��������Ϣ
		StuDate sd=(StuDate)getSession().get(StuDate.class, studate.getScno());
		sd.setStuname(studate.getStuname());
		sd.setForeigname(studate.getForeigname());
		sd.setBridtime(studate.getBridtime());
		return true;
	}//ִ���޸�
	
}
