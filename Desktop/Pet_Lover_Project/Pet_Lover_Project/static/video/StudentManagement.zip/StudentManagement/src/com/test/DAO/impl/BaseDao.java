package com.test.DAO.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * ��ȡSession����Ĺ�����
 * @author Administrator
 *
 */
public class BaseDao {

	private SessionFactory sf;

	public void setSf(SessionFactory sf) {
		this.sf = sf;
	}
	
	public Session getSession(){
		return sf.getCurrentSession();
	}
	
}





